

<?php $__env->startSection('admin_contents'); ?>


<div class = "container">




    <div class="row justify-content-center">
      <div class="col-xl-12 col-lg-12 col-md-12">
        <div class="card shadow-sm my-5">
          <div class="card-body p-0">
            <div class="row">
              <div class="col-lg-12">
                <div class="login-form">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Edit Profile</h1>
                  </div>

      <form action = "<?php echo e(route('update.profile')); ?>" method = "post" class="user">
         <?php echo csrf_field(); ?>
        <div class="form-group">
            
            <input type = "hidden" value = "<?php echo e(Auth::User()->id); ?>" name = "user_id">

          <div class="form-row">
            <div class="col-md-12">
              <label for="exampleFormControlSelect1">Name<code>*</code></label>
         <input type="text" class="form-control" id="exampleInputFirstName" value = "<?php echo e(Auth::User()->name); ?>" name = "user_name" required>
             
            </div>


          
            
          </div>
         
        </div>
        
        
        <div class="form-group">

          <div class="form-row">
            <div class="col-md-12">
              <label for="exampleFormControlSelect1">Email<code>*</code></label>
         <input type="email" class="form-control" id="exampleInputFirstName" value = "<?php echo e(Auth::User()->email); ?>" name = "user_email" required>
             
            </div>


          
            
          </div>
         
        </div>
        
        
        <div class="form-group">

          <div class="form-row">
            <div class="col-md-12">
              <label for="exampleFormControlSelect1">Contact Number<code>*</code></label>
         <input type="text" class="form-control" id="exampleInputFirstName" value = "<?php echo e(Auth::User()->phone); ?>" name = "user_phone" required>
             
            </div>


          
            
          </div>
         
        </div>
        
       
        <div class="form-group">
          <button type="submit" class="btn btn-primary btn-block">Update Profile</button>
        </div>
        
      </form>
                  <hr>
                  <div class="text-center">
  
  
                  </div>
                  <div class="text-center">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  
  
  
  
  <script>
  
  $(document).ready(function() {
  $('#summernote').summernote();
});
  
  </script>
  
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/koraw797/public_html/admin.4med.in/resources/views/admin/profiles/view.blade.php ENDPATH**/ ?>