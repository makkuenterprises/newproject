

<?php $__env->startSection('admin_contents'); ?>




        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <!--<div class="d-sm-flex align-items-center justify-content-between mb-4">-->
          <!--  <h1 class="h3 mb-0 text-gray-800">PRODUCTS</h1>-->
          <!--  <ol class="breadcrumb">-->
          <!--     <a href = "<?php echo e(route('add.product')); ?>" class = "btn btn-primary" style = "float: right;"> Add Product </a>-->
          <!--  </ol>-->
          <!--</div>-->

          <div class="row">
           
            <div class="col-lg-12">
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Delivery Process</h6>
                </div>
                <div class="table-responsive p-3">
                  <table class="table align-items-center table-flush table-hover" id = "dataTableHover">
                    <thead class="thead-light">
                      <tr>
                        <th>Sr No</th>
                         <th>Image</th>
                        <th>User Name</th>
                        <th>Email</th>
                        <th>Contact No.</th>
                         <th>View</th>
                        
                         <th>Download Image</th>
                        
                       
                        
                        
                      </tr>
                    </thead>
                    <tfoot>
                      <tr>
                         <th>Sr No</th>
                         <th>Image</th>
                         <th>User Name</th>
                         <th>Email</th>
                         <th>Contact No.</th>
                         <th>View</th>
                          
                         <th>Download Image</th>
                        
                        
                      </tr>
                    </tfoot>
                    <tbody>
                    <?php $i=1;  ?>
                      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                      <tr>
                        <td><?php echo e($i++); ?> </td>
                        <td> 
                         <img src = "https://4med.in/uploads/prescription/<?php echo e($row->image); ?>" width = "100px" height = "100px">
                        </td>
                        <td> <?php echo e($row->name); ?>  </td>
                        <td>  <?php echo e($row->email); ?> </td>
                        <td>
                             
                          <?php echo e($row->phone); ?>

                        </td>
                        
                        <td>
                          
                           <a href = "<?php echo e(URL::to('view/prescriptions/orders/'.$row->id)); ?>" class = "btn btn-warning  btn-sm"> <i class = "fa fa-eye"> </i> </a>
                           
                        </td>
                        
                       
                         <td>
                          
                           <a href = "<?php echo e(URL::to('download/image/'.$row->id)); ?>" class = "btn btn-success  btn-sm"> <i class = "fa fa-download"> </i> </a>
                           
                        </td>
                        
                        
                        
                       
                      </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                  
                  
                   
                </div>
              </div>
            </div>
          </div>
          <!--Row-->
  <!--<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> -->
  <!--         <div class = "text-center">-->
  <!--  <?php if($row->verified == 2): ?>-->
  <!--   <a href = "<?php echo e(URL::to('prescription/order/shipped/'.$row->id )); ?>" class = "btn btn-warning btn-block"> Shipped Order </a>-->
  <!--  <?php elseif($row->verified == 3): ?>-->
  <!--  <a href = "<?php echo e(URL::to('prescription/order/delivered/'.$row->id )); ?>" class = "btn btn-success btn-block"> Delivered </a>-->
  <!--   <?php elseif($row->verified == 4): ?>-->
  <!--  <div class = "text-center">-->
  <!--   <strong class = "badge badge-success text-center" style = "font-size:20px;"> Product Deleivered!! </strong>-->
  <!--  </div>-->
  <!--  <?php else: ?>-->
  <!--   <div class = "text-center">-->
  <!--   <strong class = "badge badge-danger text-center" style = "font-size:20px;"> Product Cancelled!! </strong>-->
  <!--  </div>-->
  <!--  <?php endif; ?>-->
  <!--  </div>-->
  <!--  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->

          
        </div>
        <!---Container Fluid-->
        
        
         
        
        
        <?php $__env->stopSection(); ?>
     
<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/koraw797/public_html/admin.4med.in/resources/views/admin/prescriptions/final_delivery.blade.php ENDPATH**/ ?>