

<?php $__env->startSection('admin_contents'); ?>




        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">User Roles</h1>
            <ol class="breadcrumb">
               <a href = "<?php echo e(route('admin.users.add')); ?>" class = "btn btn-primary" style = "float: right;"> Add Users </a>
            </ol>
          </div>

          <div class="row">
           
            <div class="col-lg-12">
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">All User Roles</h6>
                </div>
                <div class="table-responsive p-3">
                  <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                    <thead class="thead-light">
                      <tr>
                        <th>Sr No</th>
                        <th>Name</th>
                         <th>Phone</th>
                         <th>Access</th>
                         <th>Action</th>
                      </tr>
                    </thead>
                    <tfoot>
                      <tr>
                         <th>Sr No</th>
                        <th>Name</th>
                         <th>Phone</th>
                         <th>Access</th>
                         <th>Action</th>
                        
                      </tr>
                    </tfoot>
                    <tbody>
                    <?php $i = 1; ?>
                      <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td> <?php echo e($i++); ?> </td>
                        <td> 
                       <?php echo e($row->name); ?>

                       
                        </td>
                        <td> <?php echo e($row->phone); ?> </td>
                        <td> 
                        
                     <?php if($row->category == 1): ?>
                    <span class="badge badge-info"> Category </span>
                    <?php else: ?>
                    <?php endif; ?>

                    <?php if($row->users == 1): ?>
                    <span class="badge badge-warning"> User </span>
                    <?php else: ?>
                    <?php endif; ?>
                    
                     <?php if($row->products == 1): ?>
                    <span class="badge badge-danger"> Products </span>
                    <?php else: ?>
                    <?php endif; ?>

                    <?php if($row->banners == 1): ?>
                    <span class="badge badge-secondary"> Banners </span>
                    <?php else: ?>
                    <?php endif; ?>

                    <?php if($row->orders == 1): ?>
                    <span class="badge badge-primary"> Orders </span>
                    <?php else: ?>
                    <?php endif; ?>

                     <?php if($row->reports == 1): ?>
                    <span class="badge badge-success"> Reports </span>
                    <?php else: ?>
                    <?php endif; ?>

                     <?php if($row->roles == 1): ?>
                    <span class="badge badge-danger"> Roles </span>
                    <?php else: ?>
                    <?php endif; ?>
                    
                     <?php if($row->return_orders == 1): ?>
                    <span class="badge badge-info"> Return Orders </span>
                    <?php else: ?>
                    <?php endif; ?>

                    
                        
                        
                        </td>
                        <td>
                        <a href = "<?php echo e(url('edit/admin/'.$row->id)); ?>" class = "btn btn-success"> <i class="fa fa-pencil-square-o" aria-hidden="true"></i> </a>
                      	<a href = "<?php echo e(url('remove/admin/'.$row->id)); ?>" class = "btn btn-danger" id = "delete"> <i class="fa fa-trash" aria-hidden="true"></i> </a>
                          
                        </td>
                        
                      </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          <!--Row-->

          
        </div>
        <!---Container Fluid-->
        
        
         
        
        
        <?php $__env->stopSection(); ?>
     
<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/koraw797/public_html/admin.4med.in/resources/views/admin/roles/all_role.blade.php ENDPATH**/ ?>