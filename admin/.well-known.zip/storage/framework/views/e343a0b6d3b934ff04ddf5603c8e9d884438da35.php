

<?php $__env->startSection('admin_contents'); ?>


 <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>-->
 
 
 
 <script>
        var base_url = '<?php echo e(url('/')); ?>';
        </script>

        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">PRODUCTS</h1>
           
          </div>

          <div class="row">
           
            <div class="col-lg-12">
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  
                  
                  <form method = "post" action = "<?php echo e(route('create.orders.med')); ?>">
                      <?php echo csrf_field(); ?>
                      <input type = "hidden" name = "order_id" value = "<?php echo e($user_info->id); ?>">
                       <input type = "hidden" name = "user_id" value = "<?php echo e($user_info->user_id); ?>">
                    <input type = "text" name = "search" class = "form-control autocomplete" placeholder = "Enter Product Name">
                    <input type = "submit" value = "submit">
                    
                     
                </form>
                  
                </div>
                
                
                
               <table>
               </table>
                
      
          
                
              </div>
            </div>
            
                <?php $__currentLoopData = $user_med; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <?php if($row->order_id == NULL): ?>
                    
                    <?php endif; ?>
                    
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                    
                        <div class = "col-lg-12">
                     <form method = "post" action = "<?php echo e(route('make.orders.med')); ?>">
                      <?php echo csrf_field(); ?>
                    <table class="table">
              
                        
                        <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Image</th>
                          <th scope="col">Product Name</th>
                          <th scope="col">Product Description</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php $__currentLoopData = $user_med; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         
                        <tr>
                          <th scope="row">1</th>
                          <td><img src = "<?php echo e($test->product_thumbnail); ?>" width = "150px" height = "150px"></td>
                          <td><?php echo e($test->product_name); ?></td>
                          <!--<td><input type = "number" name = "qty[]" class = "form-control" min = "1" required></td>-->
                           <td><?php echo $test->product_description; ?></td>
                         <td>  <a href="<?php echo e(URL::to('delete/medicine/'.$test->id)); ?>" class="btn btn-sm btn-danger" title="delete" id="delete"><i class="fa fa-trash"> </td>
                        </tr>
                        
                        <input type = "hidden" name = "product_id" value = "<?php echo e($test->product_id); ?>">
                        <input type = "hidden" name = "user_id" value = "<?php echo e($test->user_id); ?>">
                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                      </tbody>
                       
                       
                   
                      
                </table>
               <?php
                    $med = DB::table('add_medicines')->first();
                    
               ?> 
                    <?php if($med == NULL): ?>
                    
                    <?php else: ?>
                        <input type = "submit" value = "submit" class = "btn btn-warning btn-block">     
                    <?php endif; ?>
               
                
                 
                   </form>     
                    
            </div>
            
            
                
                    
                    
                    
                
              
                 
                
         
           
            
          </div>
          <!--Row-->

          
        </div>
        <!---Container Fluid-->
        
         <script type="text/javascript">
            
            $(function () {
                $(".autocomplete").autocomplete({
                    source: base_url + "/searchCities", 
                    minLength: 2,
                    select: function (event, ui) {
                        
            //            console.log(ui.item.value);
                    }


                });
});

        </script>
        
        
        

   
         
        <script>
            $(document).ready( function () {
                $('#productTable').DataTable();
                
            } );
        </script>
        
        <?php $__env->stopSection(); ?>
     
<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/koraw797/public_html/admin.4med.in/resources/views/admin/prescriptions/make_order.blade.php ENDPATH**/ ?>