

<?php $__env->startSection('admin_contents'); ?>




        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <!--<div class="d-sm-flex align-items-center justify-content-between mb-4">-->
          <!--  <h1 class="h3 mb-0 text-gray-800">PRODUCTS</h1>-->
          <!--  <ol class="breadcrumb">-->
          <!--     <a href = "<?php echo e(route('add.product')); ?>" class = "btn btn-primary" style = "float: right;"> Add Product </a>-->
          <!--  </ol>-->
          <!--</div>-->

          <div class="row">
           
            <div class="col-lg-12">
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Update Quantity</h6>
                </div>
               <form method="post" action="<?php echo e(url('update/cart/'.$carts->product_id)); ?>">
                <?php echo csrf_field(); ?>
                 <input type = "number" name = "qty" value = "<?php echo e($carts->qty); ?>" class = "form-control">
                 <button type = "submit" class = "btn btn-success"> Submit </button>
               </form>
            </div>
          </div>
    

          
        </div>
        <!---Container Fluid-->
        
        
         
        
        
        <?php $__env->stopSection(); ?>
     
<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/koraw797/public_html/admin.4med.in/resources/views/admin/prescriptions/update_qty.blade.php ENDPATH**/ ?>