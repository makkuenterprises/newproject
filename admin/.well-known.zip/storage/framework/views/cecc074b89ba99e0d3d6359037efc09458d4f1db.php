

<?php $__env->startSection('admin_contents'); ?>




        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"> View Orders </h1>
           
          </div>

          <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header"><strong>Orders</strong> Details</div>
                <div class = "card-body">
                <table class = "table">
                	<tr>
                		<th> Name: </th>
                		<td> <?php echo e($orders->name); ?>  </td>
                	</tr>
                	<tr>
                		<th> Phone: </th>
                		<td> <?php echo e($orders->phone); ?>  </td>
                	</tr>
                	<tr>
                		<th> Payment Type: </th>
                		<?php if($orders->payment_type == 'cashon'): ?>
                		    <td> <span class = "badge badge-info"> Cash Mode </span>  </td>
                		<?php else: ?>
                		   <td> <span class = "badge badge-success"> Online Mode </span>  </td>
                		<?php endif; ?>
                	
                	</tr>
                	<tr>
                		<th> Payment ID: </th>
                		<?php if($orders->transaction_id == NULL): ?>
                		  <td>  <span class = "badge badge-warning"> Null </span> </td>
                		<?php else: ?>
                		<td> <?php echo e($orders->transaction_id); ?>  </td>
                		<?php endif; ?>
                	    
                	</tr>
                	<tr>
                		<th> Total: </th>
                		<td> &#x20b9; <?php echo e($orders->amount); ?>  </td>
                	</tr>
                	<tr>
                		<th> Month: </th>
                		<td> <?php echo e($orders->month); ?>  </td>
                	</tr>
                	<tr>
                		<th> Order Date: </th>
                		<td> <?php echo e($orders->date); ?>  </td>
                	</tr>
                	<?php if($orders->delivery_date == NULL): ?>
                	
                	<?php else: ?>
                	    <tr>
                		<th> Delivery Date: </th>
                		
                	<td>	<?php echo e(date("d-m-Y", strtotime($orders->delivery_date))); ?>  </td>
                	</tr>
                	<?php endif; ?>
                	
                </table>
            </div>
            </div>
        </div>

       <div class="col-md-6 mt-4">
            <div class="card">
                <div class="card-header"><strong>Shipping</strong> Details</div>
                <div class = "card-body">
                <table class = "table">
                	<tr>
                		<th> Name: </th>
                		<td> <?php echo e($user_info->name); ?>  </td>
                	</tr>
                	<tr>
                		<th> Phone: </th>
                		<td> <?php echo e($user_info->phone); ?>  </td>
                	</tr>
                	<tr>
                		<th> Email: </th>
                		<td> <?php echo e($user_info->email); ?>  </td>
                	</tr>
                	<tr>
                		<th> Status: </th>
                		<?php if($orders->status == 0): ?>
                		 <td> <span class = "badge badge-warning"> Pending  </span> </td>
                			<?php elseif($orders->status == 1): ?>
                		 <td>	<span class = "badge badge-info"> Payment Accept </span> </td>
                			<?php elseif($orders->status == 2): ?>
                		 <td>	<span class = "badge badge-warning"> Progress </span> </td>
                			<?php elseif($orders->status == 3): ?>
                		 <td>	<span class = "badge badge-success"> Delivered </span> </td>
                			<?php else: ?>
                		<td>	<span class = "badge badge-danger"> Cancel </span> </td>
                			<?php endif; ?>
                	</tr>
                	<tr>
                		<th> Address: </th>
                		<th class = "text-success">
                		
                		    <?php echo e($user_info->full_address); ?>

                		    
                		</th>
                	</tr>
                	
                </table>
            </div>
            </div>
        </div>

    </div>

          <!--Row-->
          
          
           <div class = "row mt-4">

    	<div class="card pd-20 pd-sm-40 col-sm-12">
         

          <div class="table-wrapper">
            <table  class="table display responsive nowrap">
              <thead>
                <tr>
                  <th class="wd-15p">Sr No</th>
                  <th class="wd-15p">Product Name</th>
                  <th class="wd-15p">Image</th>
                  <th class="wd-15p">Product Size</th>  
                  <th class="wd-20p">Quantity</th>
                  <th class="wd-20p">Unit Price</th>
                  <th class="wd-20p">Total</th>
                </tr>
              </thead>
              <tbody>
                  <?php $i = 1; ?>
              <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                	
                  <td> <?php echo e($i++); ?>  </td>
                  <td> <?php echo e($row->product_name); ?>  </td>
                   <td><img src = "<?php echo e($row->product_thumbnail); ?>" height = "70px" width = "60px"></td>
                  
                  <td> <?php echo e($row->product_size); ?>  </td>
                 
                  <td> <?php echo e($row->quantity); ?> </td>
                 
                  <td> &#x20b9; <?php echo e($row->singleprice); ?>  </td>
                  <td>  &#x20b9; <?php echo e($row->totalprice); ?>  </td>
                  
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              </tbody>
            </table>
          </div><!-- table-wrapper -->
        </div><!-- card -->


    </div>
    
    <br>
    
    
    <?php if($orders->status == 0): ?>
    <a href = "<?php echo e(url('payment/accept/'.$orders->id)); ?>" class = "btn btn-info btn-block"> Payment Accept </a>
    <a href = "<?php echo e(url('payment/cancel/'.$orders->id)); ?>" class = "btn btn-danger btn-block"> Order Cancel </a>
    <?php elseif($orders->status == 1): ?>
    <a href = "<?php echo e(url('process/delivery/'.$orders->id)); ?>" class = "btn btn-info btn-block"> Process Delivery </a>
    <?php elseif($orders->status == 2): ?>
     <a href = "<?php echo e(url('product/delivered/'.$orders->id)); ?>" class = "btn btn-success btn-block"> Delivered </a>
    <?php elseif($orders->status == 4): ?>
    <div class = "text-center">
     <strong class = "badge badge-success text-center" style = "font-size:20px;"> Product Cancelled!! </strong>
    </div>
    <?php else: ?>
    <div class = "text-center">
     <strong class = "badge badge-success text-center" style = "font-size:20px;"> Product Deleivered!! </strong>
    </div>
    <?php endif; ?>
   
   
   

          
        </div>
        <!---Container Fluid-->
        
        
         
        
        
        <?php $__env->stopSection(); ?>
     
<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/koraw797/public_html/admin.4med.in/resources/views/admin/orders/view_order.blade.php ENDPATH**/ ?>