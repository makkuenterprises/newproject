

<?php $__env->startSection('admin_contents'); ?>


 <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>-->
 
 
 
 <script>
        var base_url = '<?php echo e(url('/')); ?>';
        </script>

        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">View Carts</h1>
           
          </div>

          <div class="row">
           
            <div class="col-lg-12">
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  
                  
                 
                  
                </div>
                
                
                
               <table>
               </table>
                
      
          
                
              </div>
            </div>
            
              
                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <?php if($cart->id == NULL): ?>
                    
                    <?php endif; ?>
                    
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                    
                        <div class = "col-lg-12">
                          
                          <div class = "text-center"> 
                            <a href = "<?php echo e(route('clear.cart')); ?>" class = "btn btn-danger" id="delete"> Clear All Cart </a>
                          </div>
                    <table class="table mt-5">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Image</th>
                          <th scope="col">Product Name</th>
                          <th scope="col">Product Quantity</th>
                          <th scope="col">Update Quantity</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         
                        <tr>
                          <th scope="row">1</th>
                          <td><img src = "<?php echo e($car->product_thumbnail); ?>" width = "150px" height = "150px"></td>
                          <td><?php echo e($car->product_name); ?></td>
                           <form method = "post" action = "">
                      <?php echo csrf_field(); ?>
                          <td><input type = "number" name = "qty" value = "<?php echo e($car->qty); ?>" class = "form-control" min = "1" readonly></td>
                           <td> <a href = "<?php echo e(URL::to('update/qty/'.$car->product_id)); ?>" class = "btn btn-primary"> Update Quantity  </td>
                           <td>  <a href="<?php echo e(URL::to('delete/cart/'.$car->id)); ?>" class="btn btn-sm btn-danger" title="delete" id="delete"><i class="fa fa-trash"> </td>
                        </form>  
                        </tr>
                        
                       
                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                      </tbody>
                </table>
                 
                        
                    
            </div>
            
            <div class="col-lg-12">
                            <form action="<?php echo e(route('book.order')); ?>" method = "post" enctype="multipart/form-data" id="bookorderform">
                            <?php echo csrf_field(); ?>
                             <?php $__currentLoopData = $cartproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="user_id" value="<?php echo e($item->user_id); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!--<input type="hidden" name="address_id" value="<?php echo e($useraddress[0]->id); ?>">-->
                            <!--<input type ="hidden" name="payment_id" value="">-->
                            <!--<input type = "hidden" name = "addresss" value = "<?php echo e($useraddress[0]->fullname); ?>,-->
                            <!--                                                 <?php echo e($useraddress[0]->full_address); ?>, <?php echo e($useraddress[0]->city); ?>, <?php echo e($useraddress[0]->state); ?>,-->
                            <!--                                                 <?php echo e($useraddress[0]->pin_code); ?>,-->
                            <!--                                                 <?php echo e($useraddress[0]->alternate_phone); ?>">-->
                            <div class="your-order-area">
                                <h3>Your order</h3>
                                <div class="your-order-wrap gray-bg-4">
                                    <div class="your-order-info-wrap">
                                        <div class="your-order-info">
                                            
                                        </div>
                                        <div class="your-order-middle">
                                            <ul>
                                                <?php $__currentLoopData = $cartproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li> <?php echo e($item->product_name); ?> <span>&#8377; <?php echo e(number_format($item->price * $item->qty,2)); ?> </span></li>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                        <div class="your-order-info order-subtotal">
                                            <ul>
                                                <li>Subtotal <span>&#8377;<?php echo e(number_format($totalprice,2)); ?> </span></li>
                                            </ul>
                                        </div>
                                        <div class="your-order-info order-shipping">
                                            <ul>
                                                <li>Shipping Charge
                                                <?php if($totalprice < 500): ?> 
                                                    <span>&#8377; 50.00 </span>
                                                    <input type ="hidden" name="shipping_charge" value="50.00">
                                                <?php else: ?>
                                                    <span>&#8377; 0.00 </span>
                                                    <input type ="hidden" name="shipping_charge" value="0.00">
                                                <?php endif; ?>
                                                
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="your-order-info order-total">
                                            <ul>
                                                <li>Total
                                                    <?php if($totalprice < 500): ?>
                                                       <span>&#8377; <?php echo e(number_format($totalprice + 50.00,2)); ?> </span>
                                                       <input type = "hidden" name = "total" value = "<?php echo e(number_format($totalprice + 50.00,2)); ?>">
                                                    <?php else: ?>
                                                        <span>&#8377; <?php echo e(number_format($totalprice + 00.00,2)); ?> </span>
                                                        <input type = "hidden" name = "total" value = "<?php echo e(number_format($totalprice + 00.00,2)); ?>">
                                                    <?php endif; ?>
                                                
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="payment-method">
        
                                        <div class="pay-top sin-payment">
                                            <input id="payment-method-3" class="input-radio cash" type="radio" name = "payment" value="cash" name="payment_method" checked>
                                            <label for="payment-method-3">Cash on delivery </label>
                                            <div class="payment-box payment_method_bacs">
                                               
                                            </div>
                                        </div>
                                       
                                    </div>
                                </div>
                                <div class="Place-order text-center">
                                    <button type = "submit" class = "btn btn-danger" id="rzp-button1">Place Order</button>
                                </div>
                            </div>
                            </form>
                            
                            
                            
                            
                          <!--   <form action="https://test.cashfree.com/billpay/checkout/post/submit" name="frm1" method="post">-->
                          <!--    <p>Please wait.......</p>-->
                        
                          <!--    <input type="hidden" name="signature" value='QN09Elp5Sb267qhXFtIa1+6K3Krdva/Ibu4XDuHj6wc='/>-->
                          <!--    <input type="hidden" name="orderNote" value="test"/>-->
                          <!--    <input type="hidden" name="orderCurrency" value="INR"/>-->
                          <!--    <input type="hidden" name="customerName" value="Sugandh"/>-->
                          <!--    <input type="hidden" name="customerEmail" value="sugandhkumar9@gmal.com"/>-->
                          <!--    <input type="hidden" name="customerPhone" value="8271168973"/>-->
                          <!--    <input type="hidden" name="orderAmount" value="130"/>-->
                          <!--    <input type ="hidden" name="notifyUrl" value="https://4med.in/response"/>-->
                          <!--    <input type ="hidden" name="returnUrl" value="https://4med.in/response"/>-->
                          <!--    <input type="hidden" name="appId" value="51308c8eb15e6f966b91473a380315"/>-->
                          <!--    <input type="hidden" name="orderId" value="123555"/>-->
                          <!--</form>-->
                        </div>
                    
                    
                    
                
              
                 
                
         
           
            
          </div>
          <!--Row-->

          
        </div>
        <!---Container Fluid-->
        
         <script type="text/javascript">
            
            $(function () {
                $(".autocomplete").autocomplete({
                    source: base_url + "/searchCities", 
                    minLength: 2,
                    select: function (event, ui) {
                        
            //            console.log(ui.item.value);
                    }


                });
});

        </script>
        
        
        

   
         
        <script>
            $(document).ready( function () {
                $('#productTable').DataTable();
                
            } );
        </script>
        
        <?php $__env->stopSection(); ?>
     
<?php echo $__env->make('admin.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/koraw797/public_html/admin.4med.in/resources/views/admin/prescriptions/view_carts.blade.php ENDPATH**/ ?>