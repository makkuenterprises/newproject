<?php

namespace Zendesk\API\Exceptions;

/**
 * AuthException is for auth specific errors
 * @package Zendesk\API
 */
class AuthException extends \Exception
{
}
