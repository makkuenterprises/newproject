<?php

namespace Zendesk\API\Exceptions;

class RouteException extends \Exception
{
}
