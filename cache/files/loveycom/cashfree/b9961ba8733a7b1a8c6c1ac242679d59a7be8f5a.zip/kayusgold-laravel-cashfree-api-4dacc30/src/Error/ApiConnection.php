<?php

namespace LoveyCom\CashFree\Error;

class ApiConnection extends Base
{ }
