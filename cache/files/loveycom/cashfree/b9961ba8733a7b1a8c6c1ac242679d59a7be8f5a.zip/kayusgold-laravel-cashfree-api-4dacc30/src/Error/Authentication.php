<?php

namespace LoveyCom\CashFree\Error;

class Authentication extends Base
{ }
