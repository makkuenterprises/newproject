<?php

namespace LoveyCom\CashFree\Error;

class Api extends Base
{ }
